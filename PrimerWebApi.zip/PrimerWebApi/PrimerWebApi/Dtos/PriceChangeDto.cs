﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PrimerWebApi.Dtos
{
    public class PriceChangeDto
    {
        public long Id { get; set; }
        public double Price { get; set; }
    }
}
