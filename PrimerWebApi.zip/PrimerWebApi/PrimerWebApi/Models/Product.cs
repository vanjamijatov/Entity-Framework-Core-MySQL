﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PrimerWebApi.Models
{
    public class Product
    {
        public long Id { get; set; }

        [MinLength(3)]
        [MaxLength(100)]
        public string Name { get; set; }

        public string Color { get; set; }

        [Range(0.1, 10000)]
        public double Price { get; set; }

        public long CategoryId { get; set; }
        public virtual ProductCategory Category { get; set; }

        public Product(int id, string name, string color, double price, ProductCategory category)
        {
            this.Id = id;
            this.Name = name;
            this.Color = color;
            this.Price = price;
            this.CategoryId = category.Id;
            this.Category = category;
        }

        public Product() { }
    }
}
