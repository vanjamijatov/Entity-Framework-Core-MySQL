﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace PrimerWebApi.Models
{
    public class MyDbContext: DbContext
    {
        public DbSet<Product> Products { get; set; }
        public DbSet<ProductCategory> Categories { get; set; }

        public MyDbContext(DbContextOptions<MyDbContext> options) : base(options) { }

        // only for testing purposes
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<ProductCategory>().HasData(
                new ProductCategory { Id = 1, Name = "Clothes", Products = new List<Product>() },
                new ProductCategory { Id = 2, Name = "Footwear", Products = new List<Product>() },
                new ProductCategory { Id = 3, Name = "Food", Products = new List<Product>() }
            );


            modelBuilder.Entity<Product>().HasData(
                new Product { Id = 1, Name = "Jacket", Color = "black", Price = 40.3, CategoryId = 1 },
                new Product { Id = 2, Name = "Shoes", Color = "blue", Price = 52.2, CategoryId = 2 },
                new Product { Id = 3, Name = "T-shirt", Color = "white", Price = 4, CategoryId = 1 },
                new Product { Id = 4, Name = "Bread", Color = "white", Price = 0.5, CategoryId = 3 },
                new Product { Id = 5, Name = "Boots", Color = "brown", Price = 88.8, CategoryId = 2 }
            );
        }
    }
}
